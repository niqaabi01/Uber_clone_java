// creating an interface for car that will get used in uberRide as well as the rider class
interface Vehicle {
    
    public String getNumberPlate();
    public String getColor();
    public String getModel();
}